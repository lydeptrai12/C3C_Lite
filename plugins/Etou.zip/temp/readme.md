xoá nó đi cũng được
