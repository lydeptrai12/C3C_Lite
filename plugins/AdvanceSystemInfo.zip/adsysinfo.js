var sys = global.nodemodule["systeminformation"];

var info = async function(type, data){
	var systemInfo;
	try{
		systemInfo = await sys.system();
	}
	catch(err){
		return{
			handler: "internal",
			data: `error while getting system info!`
		}
	}
	var cpuInfo;
	try{
		cpuInfo = await sys.cpu();
	}
	catch(err){
		return{
			handler: "internal",
			data: `error while getting cpu info!`
		}
	}
	var cpuTemp;
	try{
		cpuTemp = await sys.cpuTemperature();
	}
	catch(err){
		return{
			handler: "internal",
			data: `error while getting cpu temperature!`
		}
	}
	var cpuSpeed;
	try{
		cpuSpeed = await sys.cpuCurrentspeed();
	}
	catch(err){
		return{
			handler: "internal",
			data: `error while getting cpu speed!`
		}
	}
	var ramMem;
	try{
		ramMem = await sys.mem();
	}
	catch(err){
		return{
			handler: "internal",
			data: `error while getting ram memory!`
		}
	}
	var ramInfo;
	try{
		ramInfo = await sys.memLayout();
	}
	catch(err){
		return{
			handler: "internal",
			data: `error while getting ram info!`
		}
	}
	var gpuInfo;
	try{
		gpuInfo = await sys.graphics();
	}
	catch(err){
		return{
			handler: "internal",
			data: `error while getting graphics info!`
		}
	}
	var osInfo;
	try{
		osInfo = await sys.osInfo();
	}
	catch(err){
		return{
			handler: "internal",
			data: `error while getting OS info!`
		}
	}
	/*systemInfo = JSON.parse(systemInfo);
	cpuInfo = JSON.parse(cpuInfo);
	cpuTemp = JSON.parse(cpuTemp);
	cpuSpeed = JSON.parse(cpuSpeed);
	ramMem = JSON.parse(ramMem);
	ramInfo = JSON.parse(ramInfo);
	gpuInfo = JSON.parse(gpuInfo);
	osInfo = JSON.parse(osInfo);*/
	console.log(systemInfo,cpuInfo,cpuTemp,cpuSpeed,ramMem,ramInfo,gpuInfo,osInfo);
	var str1 = `      -Avarage: ${cpuSpeed.avg}GHz\r\n`;
	for(i=0;i<cpuInfo.cores;i++){
		str1 += `      -Thread#${i}: ${cpuSpeed.cores[i]}GHz\r\n`;
	}
	var str2 = `      -Avarage: ${cpuTemp.main}°C\r\n`;
	for(i=0;i<cpuInfo.physicalCores;i++){
		str2 += `      -Core#${i}: ${cpuTemp.cores[i]}°C\r\n`;
	}
	var str3 = '';
	for(i=0;i<ramInfo.length;i++){
		str3 += `    +Ram#${i}:\r\n      -Manufacturer: ${ramInfo[i].manufacturer}\r\n      -Size: ${(((ramInfo[i].size/1024)/1024)/1024).toFixed(2)}GB\r\n      -Slot: Slot#${(ramInfo[i].bank).slice(5, (ramInfo[i].bank).length)}\r\n      -Type: ${ramInfo[i].type}\r\n      -Clockspeed: ${ramInfo[i].clockSpeed}\r\n`;
	}
	var rep = `*CONFIGURATION*:\r\n  -Manufacturer: ${systemInfo.manufacturer}\r\n  -Model: ${systemInfo.model}\r\n*OS*:\r\n  -Platform: ${osInfo.platform}\r\n  -Distro: ${osInfo.distro}\r\n  -Build: ${osInfo.build}\r\n  -arch: ${osInfo.arch}\r\n  -UEFI: ${osInfo.uefi}\r\n*CPU*:\r\n  -Manufacturer: ${cpuInfo.manufacturer}\r\n  -Brand: ${cpuInfo.brand}\r\n  -Vendor: ${cpuInfo.vendor}\r\n  -Basespeed: ${cpuInfo.speed}GHz\r\n  -Maxspeed: ${cpuInfo.speedmax}GHz\r\n  -Core: ${cpuInfo.physicalCores}\r\n  -Thread: ${cpuInfo.cores}\r\n  -Socket: ${cpuInfo.socket}\r\n  -Realtime cpu data:\r\n    +Speed:\r\n${str1}    +Temperature:\r\n${str2}*RAM*:\r\n  -Total: ${(((ramMem.total/1024)/1024)/1024).toFixed(2)}GB\r\n  -Free: ${(((ramMem.free/1024)/1024)/1024).toFixed(2)}GB\r\n  -Used: ${(((ramMem.used/1024)/1024)/1024).toFixed(2)}GB\r\n  -Ram:\r\n${str3}*GPU*:\r\n  -Vendor: ${gpuInfo.controllers[0].vendor}\r\n  -Model: ${gpuInfo.controllers[0].model}\r\n  -Vram: ${gpuInfo.controllers[0].vram}`;
	return{
		handler: "internal",
		data: rep
	}
}
module.exports = {
	info
}