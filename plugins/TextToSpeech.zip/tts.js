let fetch = global.nodemodule["node-fetch"];
var streamBuffers = global.nodemodule["stream-buffers"];

var iso639_1 = ["ab","aa","af","ak","sq","am","ar","an","hy","as","av","ae","ay","az","bm","ba","eu","be","bn","bh","bi","bs","br","bg","my","ca","ch","ce","ny","zh","cv","kw","co","cr","hr","cs","da","dv","nl","dz","en","eo","et","ee","fo","fj","fi","fr","ff","gl","ka","de","el","gn","gu","ht","ha","he","hz","hi","ho","hu","ia","id","ie","ga","ig","ik","io","is","it","iu","ja","jv","kl","kn","kr","ks","kk","km","ki","rw","ky","kv","kg","ko","ku","kj","la","lb","lg","li","ln","lo","lt","lu","lv","gv","mk","mg","ms","ml","mt","mi","mr","mh","mn","na","nv","nd","ne","ng","nb","nn","no","ii","nr","oc","oj","cu","om","or","os","pa","pi","fa","pl","ps","pt","qu","rm","rn","ro","ru","sa","sc","sd","se","sm","sg","sr","gd","sn","si","sk","sl","so","st","es","su","sw","ss","sv","ta","te","tg","th","ti","bo","tk","tl","tn","to","tr","ts","tt","tw","ty","ug","uk","ur","uz","ve","vi","vo","wa","cy","wo","fy","xh","yi","yo","za","zu"];

var tts = async function tts(type, data) {
	if (data.args.length > 1) {
		var str = "";
		//Default language is the user language.
		var lang = data.resolvedLang.slice(0, 2);
		
	 	if (data.args.length > 2) {
			if (iso639_1.indexOf(data.args[1].toLocaleLowerCase()) + 1) {
				lang = data.args[1].toLocaleLowerCase();
				str = data.args.slice(2).join(" ");
			} else {
				str = data.args.slice(1).join(" ");
			}
		} else {
			str = data.args[1];
		}
		
		var url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(str)}&tl=${lang.toLocaleLowerCase()}&client=tw-ob`;
		
		let r = await fetch(url, {
			headers: {
				"User-Agent": global.config.fbuseragent
			}
		});
		
		if (r.status == 200) {
			switch (type) {
				case "Facebook":
					let buf = await r.buffer();
					let file = new streamBuffers.ReadableStreamBuffer({
						frequency: 10,
						chunkSize: 2048
					});
					file.path = "tts.mp3";
					file.put(buf);
					file.stop();
					return {
						handler: "internal-raw",
						data: {
							attachment: [file]
						}
					}
				case "Discord":
					return {
						handler: "internal-raw",
						data: {
							files: [{
								name: "tts.mp3",
								attachment: (await r.buffer())
							}]
						}
					}
			}
		} else {
			data.log(`Google rejected query with HTTP status code ${r.status} (${r.statusText}). Please create a bug report at Issues tab on C3C Repository witb this information:`, "\r\n", `Message: ${str}\tLanguage: ${lang}`);
			return {
				handler: "internal",
				data: `Error: HTTP ${r.status} ${r.statusText}`
			}
		}
	} else {
		return {
			handler: "internal",
			data: "There's no message to convert to speech."
		}
	}
}

module.exports = {
	tts: tts
}