var fetch = global.nodemodule["node-fetch"];
var cheerio = global.nodemodule["cheerio"];

var shortURL = async function (/* string */ url, /* string */ vanity) {
	try {
		var p = new URL(url);
		switch (p.protocol) {
			case "http:":
			case "https:":
				break;
			default:
				throw "Invalid protocol";
		}
	} catch (ex) {
		if (typeof ex == "string") {
			return {
				error: ex
			}
		} else {
			return {
				error: ex.toString()
			}
		}
	}
	if (typeof vanity != "string") {
		vanity = "";
	}
	if (vanity.length < 5 && vanity.length != 0) {
		return {
			error: "Vanity length must be longer or equal to 5."
		}
	}
	try {
		var html = await fetch(`https://tinyurl.com/create.php?source=indexpage&url=${encodeURIComponent(url)}&alias=${encodeURIComponent(vanity)}`).then(x => x.text());
	} catch (ex) {
		return {
			error: ex
		}
	}
	var $ = cheerio.load(html);
	return {
		url: $("#copy_div").attr('href')
	}
}

module.exports = {
	shortURL: shortURL
}
