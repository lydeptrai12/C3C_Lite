var fetch = global.nodemodule["node-fetch"];
var wait = global.nodemodule['wait-for-stuff'];
var path = global.nodemodule["path"];
var streamBuffers = global.nodemodule["stream-buffers"]

var chathook = function(type, data) {
	var content = "";
	var his=["hi","hí ae","Hí ae","hj","chào mọi người","chào m.n","hello","hê lu","hê lô","hi m.n","Hi","Hello","Hj","Hê lô","Chào m.n","hi m.n","Hi m.n","lô","Lô"]
	switch (data.msgdata.type) {
				case "message":
				case "message_reply":
					
					var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
					content = data.msgdata.body;
					if (data.msgdata.senderID == data.facebookapi.getCurrentUserID()) return false;
					break;
				default:
					return false;
			}
 
    var Nametag = global.data.cacheName["FB-" + data.msgdata.senderID]
	for (var i = 0; i < his.length; i++) {
		if (content == his[i]) {
				data.return({
			         handler: "internal",	
			         data:"Hi "+ Nametag +"\nChúc bạn một ngày tốt lành"
			        });
			return true
		}
	}

   function getFacebookAdmin() {
	var adminArray = global.config.admins.filter(arr => arr.startsWith("FB-"))
		return adminArray;
}
    
    var args = content
		.replace((/”/g), "\"")
		.replace((/“/g), "\"")
		.split(/((?:"[^"\\]*(?:\\[\S\s][^"\\]*)*"|'[^'\\]*(?:\\[\S\s][^'\\]*)*'|\/[^/\\]*(?:\\[\S\s][^/\\]*)*\/[gimy]*(?=\s|$)|(?:\\\s|\S))+)(?=\s|$)/)
		.filter(el => !(el == null || el == "" || el == " "))
		.map(xy => xy.replace(/"/g, ""));
	
    var b = args.indexOf("Thuận");
    var B = args.indexOf("thuận");
    
	 if (b !=  -1  ) {
		var d = new Date();
	    var date = d.getDate()+'-'+(d.getMonth() + 1 )+'-'+d.getFullYear();
	    var timea= d.getHours() + ":" + d.getMinutes();
			getFacebookAdmin().forEach(n => {
					data.facebookapi.sendMessage(Nametag +" vừa nhắc bạn  trong nhóm "+threadInfo.name+"\nTime: " +timea+" "+date+"\nNoi Dung: "+content, n.slice(3));
			});
 		
      }
       if (B != -1) {
           var d = new Date();
	   	   var date = d.getDate()+'-'+(d.getMonth() + 1 )+'-'+d.getFullYear();
	       var timea= d.getHours() + ":" + d.getMinutes();
			 getFacebookAdmin().forEach(n => {
					data.facebookapi.sendMessage(Nametag +" vừa nhắc bạn trong nhóm "+threadInfo.name+"\nTime: " +timea+" "+date+"\nNoi Dung: "+content, n.slice(3));
			});
      }
       if ( content.indexOf("Nguyên Phấn Đông") != -1) {
           var d = new Date();
	   	   var date = d.getDate()+'-'+(d.getMonth() + 1 )+'-'+d.getFullYear();
	       var timea= d.getHours() + ":" + d.getMinutes();
			 getFacebookAdmin().forEach(n => {
					data.facebookapi.sendMessage(Nametag +" vừa nhắc bạn trong nhóm "+threadInfo.name+"\nTime: " +timea+" "+date+"\nNoi Dung: "+content, n.slice(3));
			});
      }
}




module.exports = {
	chathook
}