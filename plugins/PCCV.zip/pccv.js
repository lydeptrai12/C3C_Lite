var fetch = global.nodemodule["node-fetch"];

var pccv = function pccv(type, data) {
	(async function () {
		var returntext = `
Để ngăn chặn COVID-19 lây lan, hãy:
1 Thường xuyên rửa tay. Dùng xà phòng và nước hoặc dung dịch rửa tay chứa cồn

2 Giữ khoảng cách an toàn với những người đang ho hoặc hắt hơi

3 Khi không thể giữ khoảng cách, hãy đeo khẩu trang

4 Không chạm vào mắt, mũi hoặc miệng

5 Khi ho hoặc hắt hơi, hãy dùng khăn giấy hoặc gập khuỷu tay lại để che mũi và miệng

6 Hãy ở nhà khi bạn cảm thấy không khỏe

7 Hãy đi khám nếu bạn bị sốt, ho và khó thở

8 Nhớ gọi điện trước để nhà cung cấp dịch vụ y tế có thể nhanh chóng hướng dẫn bạn tìm đến cơ sở y tế phù hợp. Việc này không chỉ nhằm bảo vệ bạn mà còn ngăn ngừa sự lây lan của vi-rút và các bệnh truyền nhiễm khác

9 Khẩu trang giúp ngăn chặn sự lây lan của vi-rút, không cho vi-rút truyền từ người đeo khẩu trang sang người khác. Tuy nhiên, chỉ đeo khẩu trang thôi thì không đủ để bảo vệ bạn khỏi COVID-19. Bạn phải kết hợp đeo khẩu trang với việc giữ khoảng cách và rửa tay sạch. Hãy làm theo khuyến cáo của cơ quan y tế địa phương

10 Hãy tải ứng dụng Bluezone phát hiện tiếp xúc gần , bảo vệ mình tránh khỏi Covid-19.
Link tải ứng dụng : https://play.google.com/store/apps/details?id=com.mic.bluezone&hl=vi`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"pccv\"Diamond";

data.log(onLoadText);

}
module.exports = {
	pccv: pccv
}