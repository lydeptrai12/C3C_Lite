
var speak=["[Bạn có biết?] 6663629 là một dãy số đẹp","[Bạn có biết?] cái gì chưa hiểu thì bạn chỉ cần hiểu là được","[Bạn có biết?] 20-11 là sinh nhật của Yuki","[Bạn có biết?] hãy ghi nhớ tên Yuki khi còn có thể","[Bạn có biết?] tôi không có khả năng hiểu con gái.","[Bạn có biết?] bạn đã biết.","[Bạn có biết?] việc bạn đang làm là vô nghĩa.","[Bạn có biết?] đây là một con bot wibu!","[Bạn có biết?] Bạn đang đọc dòng chữ này..... bằng mắt 👀.","[Bạn có biết?] Bạn không thể tán đổ crush của mình :))?.","[Bạn có biết?] crush của tôi là bạn?","[Bạn có biết?] lệnh này được admin Yuki code ở phiên bản 0.0.1","[Bạn có biết?] bạn đang thở","[Bạn có biết?] bạn chẳng biết gì cả","[Bạn có biết?] 1 + 1 = 2","[Bạn có biết?]:)","[Bạn có biết?] Cái con cặc:)","[Bạn có biết?] bạn là thằng đbrr","[Bạn có biết?] toicothebucuanhbanduockhong"];

var random = function(min, max) { 
	return global.plugins.librandom.getRandomNumber(min, max, 0);
}
var fact = function factt (type, data){
    var out = speak[random(0, speak.length-1)];
    return {
			handler: "internal",
			data: out
		}
}

module.exports = {
	fact
}