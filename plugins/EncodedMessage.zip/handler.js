class XMorse {
	constructor(conf) {
		this.conf = {
			space: ' ',
			short: '.',
			long: '-',
			wordsep: "/",
			...conf
		};
		
		this.set = {
			"0": "11111",
			"1": "01111",
			"2": "00111",
			"3": "00011",
			"4": "00001",
			"5": "00000",
			"6": "10000",
			"7": "11000",
			"8": "11100",
			"9": "11110",
			"A": "01",
			"B": "1000",
			"C": "1010",
			"D": "100",
			"E": "0",
			"F": "0010",
			"G": "110",
			"H": "0000",
			"I": "00",
			"J": "0111",
			"K": "101",
			"L": "0100",
			"M": "11",
			"N": "10",
			"O": "111",
			"P": "0110",
			"Q": "1101",
			"R": "010",
			"S": "000",
			"T": "1",
			"U": "001",
			"V": "0001",
			"W": "011",
			"X": "1001",
			"Y": "1011",
			"Z": "1100",
			".": "010101",
			",": "110011",
			"?": "001100",
			"'": "011110",
			"!": "101011",
			"/": "10010",
			"(": "10110",
			")": "101101",
			"&": "01000",
			":": "111000",
			";": "101010",
			"=": "10001",
			"+": "01010",
			"-": "100001",
			"_": "001101",
			"\"": "010010",
			"$": "0001001",
			"@": "011010"
		}
		
		this.reverseSet();
	}
	
	reverseSet() {
		let reversed = {};
		for (const key in this.set) {
			reversed[this.set[key]] = key;
		}

		this.reversedSet = reversed;
	}
	
	encode(msg) {
		let textlist = msg
			.split(/((?:"[^"\\]*(?:\\[\S\s][^"\\]*)*"|'[^'\\]*(?:\\[\S\s][^'\\]*)*'|\/[^/\\]*(?:\\[\S\s][^/\\]*)*\/[gimy]*(?=\s|$)|(?:\\\s|\S))+)(?=\s|$)/)
			.filter(el => !(el == null || el == "" || el == " " || !el.replace(/\s/g, '').length));
			
		textlist = textlist.map(text => {
			text = text.toLocaleUpperCase().split('');
			return text.map(ch => {
				let r = this.set[ch];
				if (!r) {
					r = this.constructor.unicodeHexMorse(ch);
				}
				return r.replace(/0/g, this.conf.short).replace(/1/g, this.conf.long);
			}).join(this.conf.space);
		});
		
		return textlist.join(this.conf.space + this.conf.wordsep + this.conf.space);
	}
	
	decode(morseo) {
		let morseList = morseo.split(this.conf.space + this.conf.wordsep + this.conf.space);
		
		morseList = morseList.map(morse => {
			morse = morse.split(this.conf.space);
			return morse.map(mor => {
				let m = mor.replace(new RegExp("((?![\\" + this.conf.short + "\\" + this.conf.long + "])(\s|\S))*", 'g'), '')
					.replace(new RegExp('\\' + this.conf.short, 'g'), '0')
					.replace(new RegExp('\\' + this.conf.long, 'g'), '1');
					
				let r = this.reversedSet[m];
				if (!r) r = this.constructor.morseHexUnicode(m);
				return r;
			}).join("");
		});
		
		return morseList.join(" ");
	}
	
	static unicodeHexMorse(ch) {
		const r = [];
		for (var i = 0; i < ch.length; i++) {
			r[i] = ('00' + ch.charCodeAt(i).toString(16)).slice(-4);
		}

		let s = r.join('');
		s = parseInt(s, 16).toString(2);
		return s;
	}
	
	static morseHexUnicode(mor) {
		mor = parseInt(mor, 2);
		if (isNaN(mor)) return '';
		return String.fromCharCode(mor);
	}
}

let b32e = global.nodemodule.base32;
let b2048e = global.nodemodule.base2048;
let b65536e = global.nodemodule.base65536;
let braillee = global.nodemodule["braille-encode"];
let ecojie = global.nodemodule["ecoji-js"];
let morsee = new XMorse();
let b58e = global.nodemodule["base-58"];
let wtf8 = global.nodemodule["wtf-8"];

let elist = {
	base32: {
		encode: true,
		decode: true,
		func: function base32(encode, data) {
			data = data + "";
			if (encode) {
				return b32e.encode(wtf8.encode(data)).toUpperCase();
			} else {
				return wtf8.decode(b32e.decode(data.toLowerCase()));
			}
		}
	},
	base64: {
		encode: true,
		decode: true,
		func: function base64(encode, data) {
			data = data + "";
			if (encode) {
				return Buffer.from(data).toString("base64");
			} else {
				return Buffer.from(data, "base64").toString("utf8");
			}
		}
	},
	hex: {
		encode: true,
		decode: true,
		func: function hex(encode, data) {
			data = data + "";
			if (encode) {
				return wtf8.encode(data).split("").map(x => x.charCodeAt(0).toString(16).pad(2)).join("").toUpperCase();
			} else {
				return wtf8.decode(data.toUpperCase().replace(/((?![A-F0-9])(\s|\S))*/g, "").match(/.{1,2}/g).map(x => String.fromCharCode(parseInt(x, 16))).join(""));
			}
		}
	},
	base65536: {
		encode: true,
		decode: true,
		func: function base65536(encode, data) {
			data = data + "";
			if (encode) {
				return b65536e.encode(new Uint8Array(wtf8.encode(data).split("").map(x => x.charCodeAt(0))));
			} else {
				return wtf8.decode(Array.from(b65536e.decode(data)).map(x => String.fromCharCode(x)).join(""));
			}
		}
	},
	base2048: {
		encode: true,
		decode: true,
		func: function base2048(encode, data) {
			data = data + "";
			if (encode) {
				return b2048e.encode(new Uint8Array(wtf8.encode(data).split("").map(x => x.charCodeAt(0))));
			} else {
				return wtf8.decode(Array.from(b2048e.decode(data)).map(x => String.fromCharCode(x)).join(""));
			}
		}
	},
	braille: {
		encode: true,
		decode: true,
		func: function braille(encode, data) {
			data = data + "";
			if (encode) {
				return braillee.encode(Buffer.from(wtf8.encode(data).split("").map(x => x.charCodeAt(0))));
			} else {
				let d = braillee.decode(data);
				return wtf8.decode(Array.from(new Int8Array(d.buffer, d.byteOffset, d.length)).map(x => String.fromCharCode(x)).join(""));
			}
		}
	},
	ecoji: {
		encode: true,
		decode: true,
		func: function ecoji(encode, data) {
			data = data + "";
			if (encode) {
				return ecojie.encode(wtf8.encode(data));
			} else {
				return wtf8.decode(ecojie.decode(data.replace(/`/g, "")));
			}
		}
	},
	morse: {
		encode: true,
		decode: true,
		func: function morse(encode, data) {
			data = data + "";
			if (encode) {
				return morsee.encode(data);
			} else {
				return morsee.decode(data);
			}
		}
	},
	base58: {
		encode: true,
		decode: true,
		func: function base58(encode, data) {
			data = data + "";
			if (encode) {
				return b58e.encode(Buffer.from(data));
			} else {
				return Buffer.from(b58e.decode(data)).toString("utf8");
			}
		}
	}
}

function getSyntaxErr() {
	let aed = Object.entries(elist).reduce((a, v) => {
		if (v[1].encode) a += (a != "" ? "; " : "") + "e." + v[0];
		if (v[1].decode) a += (a != "" ? "; " : "") + "d." + v[0];
		return a;
	}, "");
	return {
		handler: "internal",
		data: `SYNTAX ERR!\n\`${global.config.commandPrefix}encoder <e.base64/d.base64/...> <msg/encoded msg>\`\nChainable! (ex: \`${global.config.commandPrefix}encoder e.base64,e.base32 test message\`)\nAvailable (e)ncoder/(d)ecoder: ${aed}`
	}
}

let inf = async function inf(type, data) {
	if (data.args.length > 2) {
		let algo = data.args[1].split(",").map(x => x.trim());
		let msg = data.args.slice(2).join(" ");
		for (let n in algo) {
			if (algo[n].startsWith("e.")) {
				if (elist.hasOwnProperty(algo[n].slice(2))) {
					try {
						msg = elist[algo[n].slice(2)].func(true, msg);
					} catch (_) {
						return {
							handler: "internal",
							data: `Error while encoding with ${algo[n]}. ${_}`
						}
					}
				} else {
					return getSyntaxErr();
				}
			} else if (algo[n].startsWith("d.")) {
				if (elist.hasOwnProperty(algo[n].slice(2))) {
					try {
						msg = elist[algo[n].slice(2)].func(false, msg);
					} catch (_) {
						return {
							handler: "internal",
							data: `Error while decoding with ${algo[n]}. ${_}`
						}
					}
				} else {
					return getSyntaxErr();
				}
			} else {
				return getSyntaxErr();
			}
		}
		return {
			handler: "internal",
			data: (type === "Discord" ? "```\n" : "") + msg + (type === "Discord" ? "\n```" : "")
		}	
	} else {
		return getSyntaxErr();
	}
}

module.exports = {
	elist,
	inf
}