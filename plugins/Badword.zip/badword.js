!global.data.badword ? global.data.badword = {} : "";
var wait = global.nodemodule["wait-for-stuff"];
var badwordfunc = function(type, data) {
	if (data.msgdata.isGroup) {
		var allowRun = false;
		var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
		var adminIDs = threadInfo.adminIDs.map(x => x.id.toString());
		if (adminIDs.indexOf(data.msgdata.senderID) != -1) {
			allowRun = true;
		}
	    if (allowRun) {
			!global.data.badword[data.msgdata.threadID] ? global.data.badword[data.msgdata.threadID] = {} : "";
		    !global.data.badword[data.msgdata.threadID].badword ? global.data.badword[data.msgdata.threadID].badword = [] : "";
            var word = data.msgdata.body.slice(4, data.msgdata.body.length);
			if(( word != "" )&&( word != " " )){
				console.log(global.data.badword[data.msgdata.threadID].badword);
	            if ((global.data.badword[data.msgdata.threadID].badword).indexOf(word) != -1) {
				    	(global.data.badword[data.msgdata.threadID].badword).splice((global.data.badword[data.msgdata.threadID].badword).indexOf(word), 1);
					    return {
						    handler: "internal",
						    data: "Unbanned the word ("+word+")."
					    }
				    } else {
					    (global.data.badword[data.msgdata.threadID].badword).push(word);
					    return {
						    handler: "internal",
						    data: "the word ("+word+") is already banned."
					    }
				    }
			} else {
				return {
				    handler: "internal",
		   	        data: "Too few args!"
			    }
			}
	    } else {
			return {
				handler: "internal",
		   	    data: "No permission!"
			}
		}
    } else {
        return {
	    	handler: "internal",
		   	data: "This command only works in group chat!"
		}
    }
}
var showbadword = function(type, data){
	!global.data.badword[data.msgdata.threadID] ? global.data.badword[data.msgdata.threadID] = {} : "";
	!global.data.badword[data.msgdata.threadID].badwordwhitelist ? global.data.badword[data.msgdata.threadID].badwordwhitelist = [] : "";
	if((global.data.badword[data.msgdata.threadID].badword).length == 0){
	    return {
		    handler: "internal",
	        data: "badword(s): null"
	    }
	} else {
		return {
		    handler: "internal",
	        data: "badword(s): "+global.data.badword[data.msgdata.threadID].badword
	    }
	}
}

var badwordwhitelist = function(type, data){
	var choose;
	if(data.args[1] == "add"){
	    choose = 1;
	}
	else if(data.args[1] == "del"){
	    choose = 0;
	}
	else {
	    choose = 2;
	}
	var allowRun = false;
	var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
	var adminIDs = threadInfo.adminIDs.map(x => x.id.toString());
	if (adminIDs.indexOf(data.msgdata.senderID) != -1) {
			allowRun = true;
	}
	if (allowRun) {
	    !global.data.badword[data.msgdata.threadID].badwordwhitelist ? global.data.badword[data.msgdata.threadID].badwordwhitelist = [] : "";
	    var IDs = [];
	    for (var y in data.mentions) {
	    	var id = y;
	    	IDs.push(id);
	    }
	    var delID = [];
	    var addID = [];
	    if(choose == 1){
	    	addID = addID.concat(IDs);
        }
	    if(choose == 0) {
	    	delID = delID.concat(IDs);
	    }
	    if(addID.length != 0){
	        global.data.badword[data.msgdata.threadID].badwordwhitelist = (global.data.badword[data.msgdata.threadID].badwordwhitelist).concat(addID);
			return {
	    	    handler: "internal",
	            data: "đã thêm "+addID.length+" người vào badwordwhitelist!"
	        }
	    }
	    if(delID.length != 0){
	    	if(delID.length > 1){
	    		for(i=0;i<delID.length;i++){
	    			var u = (global.data.badword[data.msgdata.threadID].badwordwhitelist).indexOf(delID[i].toString());
					if(u != -1){
						removeA(global.data.badword[data.msgdata.threadID].badwordwhitelist, delID[i].toString());
					}
	    		}
	    	}
	   	    else{  
	            var u = (global.data.badword[data.msgdata.threadID].badwordwhitelist).indexOf(delID.toString());
				if(u != -1){
					removeA(global.data.badword[data.msgdata.threadID].badwordwhitelist, delID.toString());
				}
	    	}
			return {
	    	    handler: "internal",
	            data: "đã xóa "+delID.length+" người ra khỏi badwordwhitelist!"
	        }
	    }
	}
	else {
		return {
	    	    handler: "internal",
	            data: "No permission!"
	    }
	}
	if(choose == 2){
		var speech = "những người có trong badwordwhitelist là:\r\n";
		if((global.data.badword[data.msgdata.threadID].badwordwhitelist).length == 0){
			speech = speech+"null";
			return {
	    	        handler: "internal",
	                data: speech
	        }
		}
		else{
		    for(i=0;i<(global.data.badword[data.msgdata.threadID].badwordwhitelist).length;i++){
			    var cname = global.data.cacheName[(global.data.badword[data.msgdata.threadID].badwordwhitelist)[i]];
				if(cname == undefined){
					speech += ((global.data.badword[data.msgdata.threadID].badwordwhitelist)[i]).slice(3,((global.data.badword[data.msgdata.threadID].badwordwhitelist)[i]).length)+"\r\n";
				}
				else{
			        speech += cname+"\r\n";
				}
		    }
		    return {
	    	        handler: "internal",
	                data: speech
	        }
	    }
	}
}

function removeA(arr) {
    var what, a = arguments, L = a.length, ax;
    while (L > 1 && arr.length) {
        what = a[--L];
        while ((ax= arr.indexOf(what)) !== -1) {
            arr.splice(ax, 1);
        }
    }
    return arr;
}

var chathook = function (type, data) {
	!global.data.badword[data.msgdata.threadID] ? global.data.badword[data.msgdata.threadID] = {} : "";
	!global.data.badword[data.msgdata.threadID].badword ? global.data.badword[data.msgdata.threadID].badword = [] : "";
	!global.data.badword[data.msgdata.threadID].badwordwhitelist ? global.data.badword[data.msgdata.threadID].badwordwhitelist = [] : "";
	var message = data.msgdata;
	var id = data.msgdata.senderID;
	var thread = data.msgdata.threadID;
    var mistakeword;
	var allowRun = false;
	var allowRun1 = true;
	var allowRun2 = true;
    if (message.type == "message" || message.type == "message_reply") {
		if(data.msgdata.senderID != data.facebookapi.getCurrentUserID()){
			for (i=0;i<(global.data.badword[data.msgdata.threadID].badwordwhitelist).length;i++){
				if("FB-"+data.msgdata.senderID == (global.data.badword[data.msgdata.threadID].badwordwhitelist)[i]){
					allowRun1 = false;
				}
			}
			if(allowRun1){
		        var checkword = message.body.toLowerCase();
			    if(message.body != global.config.commandPrefix+"showbadword" || message.body != global.config.commandPrefix+"badwordwhitelist"){
    		        if((message.body).slice(0,3) == global.config.commandPrefix+"!!" && data.admin){
						allowRun2 = false;
					}
					if(allowRun2){
	        	        if((global.data.badword[data.msgdata.threadID].badword).length != 0){
		        	        for(i = 0; i < (global.data.badword[data.msgdata.threadID].badword).length; i++){
			        	        if (checkword.indexOf((global.data.badword[data.msgdata.threadID].badword[i]).toLowerCase()) != -1){
                                    allowRun = true;
							        mistakeword = global.data.badword[data.msgdata.threadID].badword[i];
				                }
			                }
			           }
					}
			    }
		    }
		}
		if(allowRun){
            if(global.data.badword[data.msgdata.threadID][data.msgdata.senderID] == 0 || global.data.badword[data.msgdata.threadID][data.msgdata.senderID] === undefined){
				global.data.badword[data.msgdata.threadID][data.msgdata.senderID] = 1;
				if(data.msgdata.senderID != data.facebookapi.getCurrentUserID()){
				    var buck = global.plugins.economy.getBalance("FB-"+id);
		    	    var punishbuck = Math.round(buck/2); 
				    global.plugins.economy.operator.subtract("FB-"+id, punishbuck, "badword: punish");
		     	    data.return ({
		    	        handler: "internal",
			            data: "bạn vi phạm lần 1 nên trừ 50% số tiền,\r\n Từ vi phạm là ("+mistakeword+")."
    		        });
				    return true;
				}
				else {
					global.data.badword[data.msgdata.threadID][data.msgdata.senderID] = 0;
				    return true;
				}
			}
			else if(global.data.badword[data.msgdata.threadID][data.msgdata.senderID] ==1){
				global.data.badword[data.msgdata.threadID][data.msgdata.senderID] = 2;
				if(data.msgdata.senderID != data.facebookapi.getCurrentUserID()){
    	    	    var buck = global.plugins.economy.getBalance("FB-"+id);
	            	var punishbuck = buck; 
                    global.plugins.economy.operator.subtract("FB-"+id, punishbuck, "badword: punish");
			     	data.return ({
	        	    	handler: "internal",
	    	    	    data: "bạn vi phạm lần 2 nên trừ 100% số tiền. Vi phạm 1 lần nữa bạn sẽ bị kick mà không cần báo trước!\r\n Từ vi phạm là ("+mistakeword+")."
		    		});
					return true;
				}
				else {
					global.data.badword[data.msgdata.threadID][data.msgdata.senderID] = 0;
				    return true;
				}

			}
			else if(global.data.badword[data.msgdata.threadID][data.msgdata.senderID] == 2){
				global.data.badword[data.msgdata.threadID][data.msgdata.senderID] = 0;
				        if(data.msgdata.senderID != data.facebookapi.getCurrentUserID()){
					        data.return ({
					        	handler: "internal",
			    		  		data: "bạn vi phạm lần 3 nên bị kick.\r\n Từ vi phạm là ("+mistakeword+")."
							});   
							data.facebookapi.removeUserFromGroup(id,thread);
							return true;
						}
						else {
							global.data.badword[data.msgdata.threadID][data.msgdata.senderID] = 0;
							return true;
						}
			}
		}
	}
	return false;
}

module.exports = {
	badwordfunc,
	showbadword,
	badwordwhitelist,
	chathook
}

		
	