var wait = global.nodemodule["wait-for-stuff"];
var alo = function(type, data) {
    return {
		handler: "internal",
		data: "Lô con cặc"
	}
}
var hello = function(type, data) {
    return {
		handler: "internal",
		data: "Lô con cặc"
	}
}
var lenny = function(type, data) {
	return {
		handler: "internal",
		data: "( ͡° ͜ʖ ͡°)"
	}
}
var bruh = function(type, data) {
	return {
		handler: "internal",
		data: "bủh"
	}
}
var donate = function(type, data) {
	return {
		handler: "internal",
		data: "MBBank: 0898724512"
	}
}
var admin = function(type, data) {
	return {
		handler: "internal",
		data: "Admin bot này là: Lê Đức Thuận \nGiới tính: Nam \n16 tuổi \nTính cách: Mưa nắng thất thường :)) \nLink fb: https://facebook.com/kiriha.yukii"
	}
}
var CurseCommand = function(type, data) {
    return {
		handler: "internal",
		data: " t⍑╎ᓭ ╎ᓭ ᔑ ᓵ⚍∷ᓭᒷ. D𝙹リ'ℸ ̣  ℸ ̣ ∷ᔑリᓭꖎᔑℸ ̣ ᒷ ╎ℸ ̣ , 𝙹ℸ ̣ ⍑ᒷ∷∴╎ᓭᒷ ||𝙹⚍ ∴╎ꖎꖎ..."
	}
}
var money = function(type, data){
	//global.plugins.economy.operator.add(global.plugins.economy.getID(data.msgdata, type), 1000000000, "joke: cheat");
}


module.exports = {
	lenny,
	money,
	CurseCommand,
	bruh,
	donate,
	admin,
	alo,
	hello
}