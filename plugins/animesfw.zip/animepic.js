var fetch = global.nodemodule["node-fetch"];
var streamBuffer = global.nodemodule["stream-buffers"];

function onLoad(data) {
    var onLoadText = 'loaded animepic by Kali';
    console.log(onLoadText)
}

var animepic = async function (type, data) {
    var request = encodeURIComponent(data.args.slice(1).join(" "));
    var request = request.toLowerCase()
    switch (request) {
        default: {
            return {
                handler: "internal",
                data: 'chọn kiểu thích hợp! (neko, no_tag_avatar, neko_avatars_avatar, wallpaper, kitsune, kiminonawa, waifu, keta_avatar, gecg, holo_avatar, smug, holo)'
            }
        }
            break;
        case 'wallpaper': {
            try {
                var api = 'https://api.nekos.dev/api/v3/images/sfw/img/wallpaper/';
                var str = await fetch(api);
                var str = await str.text();
                var str = str.toString().replace('{"data":{"response":{"url":"', '');
                var str = str.toString().replace('"},"status":{"code":200,"message":null,"rendered_in":"', '')
                var str = str.toString().replace('","success":true}}}', '')
                var a = str.toString().slice(-10, -1)
                var str = str.toString().replace(a, '')
                console.log(str)
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
        }
            break;
        case 'neko': {
            try {
                var api = 'https://api.nekos.dev/api/v3/images/sfw/img/neko/';
                var str = await fetch(api);
                var str = await str.text();
                var str = str.toString().slice(28, 80);
                var str = str.toString().replace('"', '')
                console.log(str)
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
        }
            break;
        case 'no_tag_avatar': {
            try {
                var api = 'https://api.nekos.dev/api/v3/images/sfw/img/no_tag_avatar/';
                var str = await fetch(api);
                var str = await str.text();
                var str = str.toString().replace('{"data":{"response":{"url":"', '');
                var str = str.toString().replace('"},"status":{"code":200,"message":null,"rendered_in":"', '')
                var str = str.toString().replace('","success":true}}}', '')
                var a = str.toString().slice(-10, -1)
                var str = str.toString().replace(a, '')
                console.log(str)
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
        }
            break;
        case 'neko_avatars_avatar': {
            try {
                var api = 'https://api.nekos.dev/api/v3/images/sfw/img/neko_avatars_avatar/';
                var str = await fetch(api);
                var str = await str.text();
                var str = str.toString().slice(28, 95)
                var str = str.toString().replace('"', '')
                console.log(str)
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
        }
            break;
        case 'kitsune': {
            try {
                var api = 'https://api.nekos.dev/api/v3/images/sfw/img/kitsune/';
                var str = await fetch(api);
                var str = await str.text();
                var str = str.toString().slice(28, 85)
                console.log(str)
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
        }
            break;
        case 'kiminonawa': {
            try {
                var api = 'https://api.nekos.dev/api/v3/images/sfw/img/kiminonawa/';
                var str = await fetch(api);
                var str = await str.text();
                var str = str.toString().slice(28, 90)
                console.log(str)
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
        }
            break;
        case 'waifu': {
            try {
                var api = 'https://api.nekos.dev/api/v3/images/sfw/img/waifu/';
                var str = await fetch(api);
                var str = await str.text();
                var str = str.toString().slice(28, 108)
                console.log(str)
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
        }
            break;
        case 'keta_avatar': {
            try {
                var api = 'https://api.nekos.dev/api/v3/images/sfw/img/keta_avatar/';
                var str = await fetch(api);
                var str = await str.text();
                var str = str.toString().slice(28, 88)
                console.log(str)
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
        }
            break;
        case 'gecg': {
            try {
                var api = 'https://api.nekos.dev/api/v3/images/sfw/img/gecg/';
                var str = await fetch(api);
                var str = await str.text();
                var str = str.toString().slice(28, 79)
                console.log(str)
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
        }
            break;
        case 'shinobu(no shinobu)': {
            try {
                var api = 'https://api.nekos.dev/api/v3/images/sfw/img/shinobu/'; //api chết mẹ rồi
                var str = await fetch(api);
                var str = await str.text();
                var str = str.toString().slice(28, 79)
                console.log(str)
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
        }
            break;
        case 'holo_avatar': {
            try {
                var api = 'https://api.nekos.dev/api/v3/images/sfw/img/holo_avatar/';
                var str = await fetch(api);
                var str = await str.text();
                var str = str.toString().slice(28, 85)
                console.log(str)
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
        }
            break;
        case 'holo': {
            try {
                var api = 'https://api.nekos.dev/api/v3/images/sfw/img/holo/';
                var str = await fetch(api);
                var str = await str.text();
                var str = str.toString().slice(28, 79)
                console.log(str)
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
        }
            break;
        case 'smug': {
            try {
                var api = 'https://api.nekos.dev/api/v3/images/sfw/img/smug/';
                var str = await fetch(api);
                var str = await str.text();
                var str = str.toString().slice(28, 79)
                console.log(str)
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
        }
            break;
    }
}

module.exports = {
    animepic: animepic,
    onLoad
}