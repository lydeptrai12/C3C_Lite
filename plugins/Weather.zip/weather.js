var messages = {
	"vi_VN": [
		"Dự báo thời tiết hôm nay tại",
		"Nhiệt độ",
		"Độ ẩm",
		"Vui lòng nhập thành phố.",
		"Đang chờ gửi toạ độ/vị trí... (thời gian chờ tối đa: 1 phút)",
		"Đã hết thời gian chờ gửi toạ độ/vị trí."
	],
	"en_US": [
		"Today's weather forecast for",
		"Temperature",
		"Humidity",
		"Please enter city.",
		"Waiting for coordinates/location... (maximum waiting time: 1 minute)",
		"Timed out waiting for coordinates/location."
	]
}

var getLang = function(){};

var onLoad = function (data) {
	var log = data.log;
	var langMap = messages;
	getLang = function (langVal, id, oLang) {
	  var lang = global.config.language;
	  if (id && global.data.userLanguage[id]) {
		lang = global.data.userLanguage[id];
		if (!langMap[lang]) {
		  log("Warning: Invalid language: ", lang, `; using ${global.config.language} as fallback...`);
		  lang = global.config.language;
		}
	  }
	  if (oLang) {
		lang = oLang;
		if (!langMap[lang]) {
		  log("Warning: Invalid language: ", lang, `; using ${global.config.language} as fallback...`);
		  lang = global.config.language;
		}
	  }

	  if (langMap[lang]) {
		return String(langMap[lang][langVal]);
	  } else {
		log("Warning: Invalid language: ", lang, "; using en_US as fallback...");
		return String((langMap["en_US"] || {})[langVal]);
	  }
	}
}
/**
 * Resolves data received from base and return formatted UserID.
 *
 * @param   {string}  type  Platform name
 * @param   {string}  data  Data to be resolved by plugins
 *
 * @return  {string}        Formatted UserID
 */
var resolveID = function (type, data) {
  switch (type) {
    case "Facebook":
      return "FB-" + data.msgdata.senderID;
    case "Discord":
      return "DC-" + data.msgdata.author.id;
    default:
      return "";
  }
};

var fs = require("fs");
var query = require("querystring");
var url = require("url");
var fetch = global.nodemodule["node-fetch"];
var path = require("path");

/**
 * Ensure <path> exists.
 *
 * @param   {string}  path  Path
 * @param   {number}  mask  Folder's mask
 *
 * @return  {object}        Error or nothing.
 */
function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return undefined;
  } catch (ex) {
    return { err: ex };
  }
}

var current = 0;
ensureExists(path.join(__dirname, "..", "Weather"));
var defaultConfig = {
	help1: 'EDIT THE OPENWEATHERMAP API KEYS: ["api key 1", "api key 2"]',
	help2: 'LEAVING API KEYS AS AN EMPTY ARRAY WILL RESULT IN ERROR!',
	apiKeys: [
		"d4e144676bd7c0e0c3c3897ff9708da9", 
		"c60fccb7b772138838b88a0bb815d175",
		"c3f985796a573f3d8f491817e7b03a63"
	]
}
if (!fs.existsSync(path.join(__dirname, "..", "Weather", "config.json"))) {
	fs.writeFileSync(path.join(__dirname, "..", "Weather", "config.json"), JSON.stringify(defaultConfig, null, 4));
	var config = defaultConfig;
} else {
	var config = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "Weather", "config.json"), {
		encoding: "utf8"
	}));
	if (config.apiKeys.length == 0) {
		config.apiKeys = [
			"d4e144676bd7c0e0c3c3897ff9708da9", 
			"c60fccb7b772138838b88a0bb815d175",
			"c3f985796a573f3d8f491817e7b03a63"
		];
	}
}

var getLocation = function getLocation(uri) {
    var u = decodeURIComponent(String(url.parse(uri, true).query["u"]));
    var loc = String(url.parse(u, true).query["where1"]).replace(/ /g, "").split(",");
    return loc.length != 2 ? null : loc;
}

var waiting = {};

var chathook = function(type, datas){
	if (datas.msgdata.type == "message" || datas.msgdata.type == "message_reply") {
		if (typeof waiting[datas.msgdata.senderID] != "undefined") {
			var atts = datas.msgdata.attachments;
			if (atts.length > 0){
				var rt = false;
				var att = null;
				for (var n in atts) {
					att = atts[n];
					//console.log(att);
					if (att.type == "share" && (att.target['__typename'] === "MessageLocation" || att.target['__typename'] === "MessageLiveLocation")) {
						rt = true;
						var location = getLocation(att.url);
						var language = global.data.userLanguage[resolveID(type, datas)] || global.config.language;
						switch (language.toLocaleLowerCase()) {
							case "zh_cn":
							case "zh_tw": 
							case "pt_br":
								language = language.toLocaleLowerCase();
							default: 
								language = language.substr(0, 2).toLocaleLowerCase();
						}
						fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${location[0]}&lon=${location[1]}&units=metric&appid=${config.apiKeys[current % config.apiKeys.length]}&lang=${language}`)
							.then(f => {
								if (f.ok) {
									return f.json();
								} else {
									throw new Error(`Cannot request to OpenWeatherMap with key ${current % config.apiKeys.length}: HTTP/1.1 ${f.status}`);
								}
							})
							.then(data => {
								datas.return({
									handler: "internal",
									data: `${getLang(0, resolveID(type, datas))} ${data.name}:\n- ${data.weather[0].description[0].toLocaleUpperCase()}${data.weather[0].description.substr(1)}\n- ${getLang(1, resolveID(type, datas))}: ${data.main.temp_min}°C => ${data.main.temp_max}°C\n- ${getLang(2, resolveID(type, datas))}: ${data.main.humidity}%`
								});
								try {
									clearTimeout(waiting[datas.msgdata.senderID]);
								} catch (ex) {}
								delete waiting[datas.msgdata.senderID];
							})
							.catch(ex => {
								datas.log("Error:", ex);
								current++;
								if (current / config.apiKeys.length == 2) {
									current = 0;
									return datas.return({
										handler: "internal",
										data: `Couldn't get weather data: ${ex}`
									});
								}
								datas.log("Trying the next keys...");
								return weather(type, datas);
							});	
					} else if (att.type == "location") {
						rt = true;
						var location = [att.latitude, att.longitude];
						var language = global.data.userLanguage[resolveID(type, datas)] || global.config.language;
						switch (language.toLocaleLowerCase()) {
							case "zh_cn":
							case "zh_tw": 
							case "pt_br":
								language = language.toLocaleLowerCase();
							default: 
								language = language.substr(0, 2).toLocaleLowerCase();
						}
						fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${location[0]}&lon=${location[1]}&units=metric&appid=${config.apiKeys[current % config.apiKeys.length]}&lang=${language}`)
							.then(f => {
								if (f.ok) {
									return f.json();
								} else {
									throw new Error(`Cannot request to OpenWeatherMap with key ${current % config.apiKeys.length}: HTTP/1.1 ${f.status}`);
								}
							})
							.then(data => {
								datas.return({
									handler: "internal",
									data: `${getLang(0, resolveID(type, datas))} ${data.name}:\n- ${data.weather[0].description[0].toLocaleUpperCase()}${data.weather[0].description.substr(1)}\n- ${getLang(1, resolveID(type, datas))}: ${data.main.temp_min}°C => ${data.main.temp_max}°C\n- ${getLang(2, resolveID(type, datas))}: ${data.main.humidity}%`
								});
								try {
									clearTimeout(waiting[datas.msgdata.senderID]);
								} catch (ex) {}
								delete waiting[datas.msgdata.senderID];
							})
							.catch(ex => {
								datas.log("Error:", ex);
								current++;
								if (current / config.apiKeys.length == 2) {
									current = 0;
									return datas.return({
										handler: "internal",
										data: `Couldn't get weather data: ${ex}`
									});
								}
								datas.log("Trying the next keys...");
								return weather(type, datas);
							});	
					}
				};
				return rt;
			}
		}
	}
    return false;
};

var weather = function (type, datas) {
	var location = datas.args.slice(1).join(" ").toLocaleLowerCase();
	if (location === "") 
		if (type === "Facebook") {
			if (typeof waiting[datas.msgdata.senderID] != "undefined") {
				try {
					clearTimeout(waiting[datas.msgdata.senderID]);
				} catch (ex) {}
			}
			waiting[datas.msgdata.senderID] = setTimeout(function (data) {
				data.return({
					handler: "internal",
					data: getLang(5, resolveID(type, datas))
				});
				try {
					clearTimeout(waiting[data.msgdata.senderID]);
				} catch (ex) {};
				delete waiting[data.msgdata.senderID];
			}, 120000, datas);
			return {
				handler: "internal",
				data: getLang(4, resolveID(type, datas))
			}
		} else {
			return {
				handler: "internal",
				data: getLang(3, resolveID(type, datas))
			}
		}
	
	var language = global.data.userLanguage[resolveID(type, datas)] || global.config.language;
	switch (language.toLocaleLowerCase()) {
		case "zh_cn":
		case "zh_tw": 
		case "pt_br":
			language = language.toLocaleLowerCase();
		default: 
			language = language.substr(0, 2).toLocaleLowerCase();
	}
	fetch(`https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(location)}&units=metric&appid=${config.apiKeys[current % config.apiKeys.length]}&lang=${language}`)
		.then(f => {
			if (f.ok) {
				return f.json();
			} else {
				throw new Error(`Cannot request to OpenWeatherMap with key ${current % config.apiKeys.length}: HTTP/1.1 ${f.status}`);
			}
		})
		.then(data => {
			datas.return({
				handler: "internal",
				data: `${getLang(0, resolveID(type, datas))} ${data.name}:\n- ${data.weather[0].description[0].toLocaleUpperCase()}${data.weather[0].description.substr(1)}\n- ${getLang(1, resolveID(type, datas))}: ${data.main.temp_min}°C => ${data.main.temp_max}°C\n- ${getLang(2, resolveID(type, datas))}: ${data.main.humidity}%`
			});
			try {
				clearTimeout(waiting[datas.msgdata.senderID]);
			} catch (ex) {}
			delete waiting[datas.msgdata.senderID];
			})
		.catch(ex => {
			datas.log("Error:", ex);
			current++;
			if (current / config.apiKeys.length == 2) {
				current = 0;
				return datas.return({
					handler: "internal",
					data: `Couldn't get weather data: ${ex}`
				});
			}
			datas.log("Trying the next keys...");
			return weather(type, datas);
		});	
}

module.exports = {
    weather,
	chathook,
	onLoad
};
