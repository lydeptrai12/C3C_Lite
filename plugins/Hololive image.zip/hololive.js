var fetch = global.nodemodule["node-fetch"];
var streamBuffer = global.nodemodule["stream-buffers"];

function onLoad(data) {
    var onLoadText = 'loaded hololive by Yuuki';
    console.log(onLoadText)
}

var hololive = async function (type, data) {
    var request = encodeURIComponent(data.args.slice(1).join(" "));
    var request = request.toLowerCase()
    switch (request) {
        default: {
            return {
                handler: "internal",
                data: 'chọn kiểu thích hợp! (rushia, pekora, coco, gura, marine) ĐÂY LÀ PLUGINS DÀNH CHO MẤY THÈNG LỌT HỐ =)))'
            }
        } 
		    break;
        case 'rushia': {
            try {
                var api = 'https://img-hololive-api.up.railway.app/rushia';
                var str = await fetch(api);	
				var str = await str.json();
                var str = str.url;
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
		}
			break;
        case 'pekora': {
            try {
                var api = 'https://img-hololive-api.up.railway.app/pekora';
                var str = await fetch(api);	
				var str = await str.json();
                var str = str.url;
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
        }
		    break;
        case 'coco': {
            try {
                var api = 'https://img-hololive-api.up.railway.app/coco';
                var str = await fetch(api);	
				var str = await str.json();
                var str = str.url;
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
		}
		    break;
        case 'gura': {
            try {
                var api = 'https://img-hololive-api.up.railway.app/gura';
                var str = await fetch(api);	
				var str = await str.json();
                var str = str.url;
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
		}
		    break;
        case 'marine': {
            try {
                var api = 'https://img-hololive-api.up.railway.app/marine';
                var str = await fetch(api);	
				var str = await str.json();
                var str = str.url;
                var img = await fetch(str);
                var buffer = await img.buffer()
                var imagesx = new streamBuffer.ReadableStreamBuffer({
                    frequency: '10',
                    chunksize: '1024',
                });
                imagesx.path = 'images.png';
                imagesx.put(buffer);
                imagesx.stop();
                return {
                    handler: 'internal',
                    data: {
                        body: '',
                        attachment: ([imagesx])
                    }
                };
            } catch (ex) { console.log(ex) };
		}
    }
}

module.exports = {
    hololive: hololive,
    onLoad
}